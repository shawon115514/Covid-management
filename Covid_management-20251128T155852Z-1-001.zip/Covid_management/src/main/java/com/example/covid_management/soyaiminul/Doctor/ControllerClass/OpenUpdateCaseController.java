package com.example.covid_management.soyaiminul.Doctor.ControllerClass;

import javafx.scene.control.*;

public class OpenUpdateCaseController
{
    @javafx.fxml.FXML
    private TextField txtDiagnosis;
    @javafx.fxml.FXML
    private Button btnEdit;
    @javafx.fxml.FXML
    private TableColumn colAuthor;
    @javafx.fxml.FXML
    private Label lblNotes;
    @javafx.fxml.FXML
    private TableColumn colDate;
    @javafx.fxml.FXML
    private Label lblStatus;
    @javafx.fxml.FXML
    private Button btnOpenCase;
    @javafx.fxml.FXML
    private TableView tblCaseHistory;
    @javafx.fxml.FXML
    private Button btnSave;
    @javafx.fxml.FXML
    private TextField txtStatus;
    @javafx.fxml.FXML
    private TableColumn colSummary;
    @javafx.fxml.FXML
    private TextArea txtCaseNotes;
    @javafx.fxml.FXML
    private Label lblTitle;
    @javafx.fxml.FXML
    private Label lblDiagnosis;

    @javafx.fxml.FXML
    public void initialize() {
    }}