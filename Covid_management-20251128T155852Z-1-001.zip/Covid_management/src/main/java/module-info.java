module com.example.covid_management {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.covid_management to javafx.fxml;
    exports com.example.covid_management;


    exports com.example.covid_management.Initial.MainDashboard;
    exports com.example.covid_management.Initial.signUp;
    exports com.example.covid_management.Initial.forgetpassword;
    exports com.example.covid_management.Initial.InternalLogin;

    exports com.example.covid_management.soyaiminul.Doctor.ControllerClass;
    exports com.example.covid_management.soyaiminul.HospitalStaff.ControllerClass;


    opens com.example.covid_management.Initial.MainDashboard to javafx.fxml;
    opens com.example.covid_management.Initial.signUp to javafx.fxml;
    opens com.example.covid_management.Initial.forgetpassword to javafx.fxml;
    opens com.example.covid_management.Initial.InternalLogin to javafx.fxml;

    opens com.example.covid_management.soyaiminul.Doctor.ControllerClass to javafx.fxml;
    opens com.example.covid_management.soyaiminul.HospitalStaff.ControllerClass to javafx.fxml;

}