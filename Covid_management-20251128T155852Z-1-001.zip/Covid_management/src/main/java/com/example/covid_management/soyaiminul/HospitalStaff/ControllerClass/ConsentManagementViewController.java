package com.example.covid_management.soyaiminul.HospitalStaff.ControllerClass;

import javafx.scene.control.*;

public class ConsentManagementViewController
{
    @javafx.fxml.FXML
    private ComboBox cmbSelectTemplate;
    @javafx.fxml.FXML
    private TableColumn colName;
    @javafx.fxml.FXML
    private Button btnSave;
    @javafx.fxml.FXML
    private TableColumn colType;
    @javafx.fxml.FXML
    private TextField txtSignerName;
    @javafx.fxml.FXML
    private Label lblTitle;
    @javafx.fxml.FXML
    private TableColumn colTemplateID;
    @javafx.fxml.FXML
    private Button btnUpload;
    @javafx.fxml.FXML
    private TableView tblConsentTemplates;

    @javafx.fxml.FXML
    public void initialize() {
    }}