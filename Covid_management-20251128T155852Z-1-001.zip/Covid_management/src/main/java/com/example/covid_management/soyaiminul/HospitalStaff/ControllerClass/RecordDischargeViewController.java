package com.example.covid_management.soyaiminul.HospitalStaff.ControllerClass;

import javafx.scene.control.*;

public class RecordDischargeViewController
{
    @javafx.fxml.FXML
    private TableColumn colOutstanding;
    @javafx.fxml.FXML
    private TextField txtDischargeDateTime;
    @javafx.fxml.FXML
    private Button btnVerify;
    @javafx.fxml.FXML
    private Button btnRecordDischarge;
    @javafx.fxml.FXML
    private TextArea txtRemarks;
    @javafx.fxml.FXML
    private TableColumn colPatient;
    @javafx.fxml.FXML
    private Label lblTitle;
    @javafx.fxml.FXML
    private TableColumn colAdmitID;
    @javafx.fxml.FXML
    private TableView tblAdmissionDetails;

    @javafx.fxml.FXML
    public void initialize() {
    }}