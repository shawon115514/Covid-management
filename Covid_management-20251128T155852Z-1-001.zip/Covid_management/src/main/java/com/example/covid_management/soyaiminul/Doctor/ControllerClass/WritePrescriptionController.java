package com.example.covid_management.soyaiminul.Doctor.ControllerClass;

import javafx.scene.control.*;

public class WritePrescriptionController
{
    @javafx.fxml.FXML
    private TableView tblCurrentMeds;
    @javafx.fxml.FXML
    private TableColumn colDrug;
    @javafx.fxml.FXML
    private TextArea txtPrescription;
    @javafx.fxml.FXML
    private TableColumn colDose;
    @javafx.fxml.FXML
    private Label lblTitle;
    @javafx.fxml.FXML
    private Button btnWriteRx;
    @javafx.fxml.FXML
    private Button btnValidate;
    @javafx.fxml.FXML
    private Button btnSend;

    @javafx.fxml.FXML
    public void initialize() {
    }}