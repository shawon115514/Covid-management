package com.example.covid_management.soyaiminul.HospitalStaff.ControllerClass;

import javafx.event.ActionEvent;
import javafx.scene.control.Label;

public class HospitalStaffDashboardController
{
    @javafx.fxml.FXML
    private Label statusLabel;

    @javafx.fxml.FXML
    public void initialize() {
    }

    @javafx.fxml.FXML
    public void NotifyFamilyrOnAction(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void AmbulanceIntakeOnAction(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void EmergencyQueueOnAction(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void ConsentManagementOnAction(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void RegisterAdmissionOnAction(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void RecordDischargeOnAction(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void signOutOnAction(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void BedAvailabilityOnAction(ActionEvent actionEvent) {
    }
}