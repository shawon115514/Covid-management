package com.example.covid_management.soyaiminul.HospitalStaff.ControllerClass;

import javafx.scene.control.*;

public class BedAvailabilityViewController
{
    @javafx.fxml.FXML
    private TableColumn colWard;
    @javafx.fxml.FXML
    private TableColumn colAvailable;
    @javafx.fxml.FXML
    private Button btnRefresh;
    @javafx.fxml.FXML
    private Button btnEdit;
    @javafx.fxml.FXML
    private CheckBox chkFilterFull;
    @javafx.fxml.FXML
    private Label lblTitle;
    @javafx.fxml.FXML
    private TableView tblWardAvailability;
    @javafx.fxml.FXML
    private TableColumn colOccupied;
    @javafx.fxml.FXML
    private TableColumn colTotalBeds;

    @javafx.fxml.FXML
    public void initialize() {
    }}