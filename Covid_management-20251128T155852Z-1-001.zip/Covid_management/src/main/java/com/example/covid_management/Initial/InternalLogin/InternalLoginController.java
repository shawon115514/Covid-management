package com.example.covid_management.Initial.InternalLogin;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class InternalLoginController {
    @javafx.fxml.FXML
    private TextField userNameTextField;
    @javafx.fxml.FXML
    private PasswordField internalUserPasswordField;
    @javafx.fxml.FXML
    private Button backBtn;
    @javafx.fxml.FXML
    private ComboBox<String> internalUserTypeComboBox;

    @javafx.fxml.FXML
    public void initialize() {
        internalUserTypeComboBox.getItems().addAll("Doctor", "Hospital Staff");

    }

    @javafx.fxml.FXML
    public void backOnAction(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/covid_management/initial/MainDashboard/MainDashboard.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setTitle("Main Dashboard");
        stage.setScene(scene);
        stage.show();
    }

    @javafx.fxml.FXML
    public void logInOnAction(ActionEvent actionEvent) throws IOException {
        if (Objects.equals(internalUserTypeComboBox.getValue(), "Doctor")) {

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/covid_management/soyaiminul/Doctor/DoctorDashboard.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setTitle("Doctor Dashboard");
            stage.setScene(scene);
            stage.show();

        }
        if
        (Objects.equals(internalUserTypeComboBox.getValue(), "Hospital Staff")) {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/covid_management/soyaiminul/HospitalStaff/HospitalStaffDashboard.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setTitle("Hospital StaffDashboard");
            stage.setScene(scene);
            stage.show();
        }
    }
}
