package com.example.covid_management.soyaiminul.HospitalStaff.ControllerClass;

import javafx.scene.control.*;

public class AmbulanceIntakeViewController
{
    @javafx.fxml.FXML
    private TextField txtETA;
    @javafx.fxml.FXML
    private TextField txtVitals;
    @javafx.fxml.FXML
    private Button btnCreateIntake;
    @javafx.fxml.FXML
    private Label lblTitle;
    @javafx.fxml.FXML
    private TextField txtCrewContact;
    @javafx.fxml.FXML
    private TableView tblAmbulanceRequests;
    @javafx.fxml.FXML
    private TableColumn colETA;
    @javafx.fxml.FXML
    private TableColumn colReqID;
    @javafx.fxml.FXML
    private TableColumn colStatus;

    @javafx.fxml.FXML
    public void initialize() {
    }}