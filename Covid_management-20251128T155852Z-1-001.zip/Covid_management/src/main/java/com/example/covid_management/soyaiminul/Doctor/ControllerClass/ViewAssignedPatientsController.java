package com.example.covid_management.soyaiminul.Doctor.ControllerClass;

import javafx.scene.control.*;

public class ViewAssignedPatientsController
{
    @javafx.fxml.FXML
    private TableColumn colName;
    @javafx.fxml.FXML
    private ComboBox cmbStatusFilter;
    @javafx.fxml.FXML
    private TableView tblPatients;
    @javafx.fxml.FXML
    private ComboBox cmbWardFilter;
    @javafx.fxml.FXML
    private TableColumn colPatientID;
    @javafx.fxml.FXML
    private MenuBar menuBar;
    @javafx.fxml.FXML
    private Button btnApply;
    @javafx.fxml.FXML
    private TableColumn colWard;
    @javafx.fxml.FXML
    private TableColumn colLastVisit;
    @javafx.fxml.FXML
    private MenuItem miExit;
    @javafx.fxml.FXML
    private TextField txtSearch;
    @javafx.fxml.FXML
    private Label lblTitle;
    @javafx.fxml.FXML
    private TableColumn colStatus;

    @javafx.fxml.FXML
    public void initialize() {
    }}