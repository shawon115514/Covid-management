package com.example.covid_management.soyaiminul.Doctor.ControllerClass;

import javafx.scene.control.*;

public class RequestTestsReferController
{
    @javafx.fxml.FXML
    private TableColumn colName;
    @javafx.fxml.FXML
    private Label lblReason;
    @javafx.fxml.FXML
    private TextArea txtReason;
    @javafx.fxml.FXML
    private TableColumn colCode;
    @javafx.fxml.FXML
    private Button btnRefer;
    @javafx.fxml.FXML
    private Label lblTitle;
    @javafx.fxml.FXML
    private ComboBox cmbTestList;
    @javafx.fxml.FXML
    private Button btnRequestTests;
    @javafx.fxml.FXML
    private Button btnValidate;
    @javafx.fxml.FXML
    private ComboBox cmbReferralDest;
    @javafx.fxml.FXML
    private CheckBox chkPriority;
    @javafx.fxml.FXML
    private TableView tblAvailableTests;

    @javafx.fxml.FXML
    public void initialize() {
    }}