package com.example.covid_management.soyaiminul.HospitalStaff.ControllerClass;

import javafx.scene.control.*;

public class NotifyFamilyViewController
{
    @javafx.fxml.FXML
    private Button btnNotify;
    @javafx.fxml.FXML
    private TableView tblFamilyContacts;
    @javafx.fxml.FXML
    private TableColumn colName;
    @javafx.fxml.FXML
    private CheckBox chkEmail;
    @javafx.fxml.FXML
    private TableColumn colChannel;
    @javafx.fxml.FXML
    private TextArea txtCustomMessage;
    @javafx.fxml.FXML
    private CheckBox chkSMS;
    @javafx.fxml.FXML
    private TableColumn colRelation;
    @javafx.fxml.FXML
    private Label lblTitle;
    @javafx.fxml.FXML
    private CheckBox chkInApp;
    @javafx.fxml.FXML
    private ComboBox cmbTemplate;
    @javafx.fxml.FXML
    private Button btnSchedule;

    @javafx.fxml.FXML
    public void initialize() {
    }}