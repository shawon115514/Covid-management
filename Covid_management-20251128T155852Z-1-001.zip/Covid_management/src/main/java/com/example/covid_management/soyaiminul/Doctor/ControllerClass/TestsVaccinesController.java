package com.example.covid_management.soyaiminul.Doctor.ControllerClass;

import javafx.scene.control.*;

public class TestsVaccinesController
{
    @javafx.fxml.FXML
    private TableColumn colResult;
    @javafx.fxml.FXML
    private TextArea txtReportNotes;
    @javafx.fxml.FXML
    private Button btnOpenReport;
    @javafx.fxml.FXML
    private TableView tblTests;
    @javafx.fxml.FXML
    private TableColumn colType;
    @javafx.fxml.FXML
    private ComboBox cmbTypeFilter;
    @javafx.fxml.FXML
    private TableColumn colDate;
    @javafx.fxml.FXML
    private Label lblTitle;
    @javafx.fxml.FXML
    private TextField txtTestSearch;

    @javafx.fxml.FXML
    public void initialize() {
    }}