package com.example.covid_management.soyaiminul.Doctor.ControllerClass;

import javafx.scene.control.*;

public class PendingDischargesController
{
    @javafx.fxml.FXML
    private TextArea txtDischargeNotes;
    @javafx.fxml.FXML
    private TableColumn colBill;
    @javafx.fxml.FXML
    private Button btnLoad;
    @javafx.fxml.FXML
    private Button btnApprove;
    @javafx.fxml.FXML
    private TableColumn colSummary;
    @javafx.fxml.FXML
    private TableColumn colPatient;
    @javafx.fxml.FXML
    private Label lblTitle;
    @javafx.fxml.FXML
    private Button btnReject;
    @javafx.fxml.FXML
    private TableView tblPendingDischarges;
    @javafx.fxml.FXML
    private Label lblDischargeNotes;
    @javafx.fxml.FXML
    private TableColumn colReqID;

    @javafx.fxml.FXML
    public void initialize() {
    }}