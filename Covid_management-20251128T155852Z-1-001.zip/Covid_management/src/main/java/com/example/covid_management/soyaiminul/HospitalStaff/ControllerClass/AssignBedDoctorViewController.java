package com.example.covid_management.soyaiminul.HospitalStaff.ControllerClass;

import javafx.scene.control.*;

public class AssignBedDoctorViewController
{
    @javafx.fxml.FXML
    private ComboBox cmbAvailableBeds;
    @javafx.fxml.FXML
    private TableView tblAdmissions;
    @javafx.fxml.FXML
    private Button btnAssign;
    @javafx.fxml.FXML
    private Button btnAutoMatch;
    @javafx.fxml.FXML
    private TableColumn colPatient;
    @javafx.fxml.FXML
    private ComboBox cmbOnDutyDoctors;
    @javafx.fxml.FXML
    private Label lblTitle;
    @javafx.fxml.FXML
    private TableColumn colAdmitID;
    @javafx.fxml.FXML
    private TableColumn colStatus;

    @javafx.fxml.FXML
    public void initialize() {
    }}