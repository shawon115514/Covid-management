package com.example.covid_management.soyaiminul.Doctor.ControllerClass;

import javafx.scene.control.*;

public class TimelineViewController
{
    @javafx.fxml.FXML
    private Button btnAddInterpretation;
    @javafx.fxml.FXML
    private TableColumn colDetails;
    @javafx.fxml.FXML
    private Button btnRequestTest;
    @javafx.fxml.FXML
    private TableColumn colDate;
    @javafx.fxml.FXML
    private Label lblTitle;
    @javafx.fxml.FXML
    private TableColumn colEventType;
    @javafx.fxml.FXML
    private TextArea txtClinicianComment;
    @javafx.fxml.FXML
    private TableView tblTimeline;

    @javafx.fxml.FXML
    public void initialize() {
    }}