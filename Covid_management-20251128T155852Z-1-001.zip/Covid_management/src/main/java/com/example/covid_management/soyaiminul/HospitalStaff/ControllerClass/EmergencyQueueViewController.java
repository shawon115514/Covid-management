package com.example.covid_management.soyaiminul.HospitalStaff.ControllerClass;

import javafx.scene.control.*;

public class EmergencyQueueViewController
{
    @javafx.fxml.FXML
    private TableColumn colEntryID;
    @javafx.fxml.FXML
    private TableView tblEmergencyQueue;
    @javafx.fxml.FXML
    private CheckBox chkCritical;
    @javafx.fxml.FXML
    private TableColumn colTriageLevel;
    @javafx.fxml.FXML
    private Button btnReorder;
    @javafx.fxml.FXML
    private TableColumn colArrivalTime;
    @javafx.fxml.FXML
    private Button btnAddEntry;
    @javafx.fxml.FXML
    private TextField txtVitals;
    @javafx.fxml.FXML
    private Label lblTitle;
    @javafx.fxml.FXML
    private TableColumn colPriority;

    @javafx.fxml.FXML
    public void initialize() {
    }}