package com.example.covid_management.soyaiminul.HospitalStaff.ControllerClass;

import javafx.scene.control.*;

public class RegisterAdmissionViewController
{
    @javafx.fxml.FXML
    private TextField txtPhone;
    @javafx.fxml.FXML
    private TableColumn colName;
    @javafx.fxml.FXML
    private Button btnSearch;
    @javafx.fxml.FXML
    private TextField txtName;
    @javafx.fxml.FXML
    private TextField txtDOB;
    @javafx.fxml.FXML
    private Button btnUpdate;
    @javafx.fxml.FXML
    private TableColumn colDOB;
    @javafx.fxml.FXML
    private Button btnCreate;
    @javafx.fxml.FXML
    private TableView tblSearchResults;
    @javafx.fxml.FXML
    private Label lblTitle;
    @javafx.fxml.FXML
    private TextField txtNationalID;
    @javafx.fxml.FXML
    private TableColumn colPatientID;

    @javafx.fxml.FXML
    public void initialize() {
    }}