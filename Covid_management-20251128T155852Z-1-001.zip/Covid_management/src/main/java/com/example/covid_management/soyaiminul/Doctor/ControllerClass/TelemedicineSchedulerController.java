package com.example.covid_management.soyaiminul.Doctor.ControllerClass;

import javafx.scene.control.*;

public class TelemedicineSchedulerController
{
    @javafx.fxml.FXML
    private Button btnAccept;
    @javafx.fxml.FXML
    private TableColumn colRequestor;
    @javafx.fxml.FXML
    private TableColumn colSlotTime;
    @javafx.fxml.FXML
    private ComboBox cmbDoctor;
    @javafx.fxml.FXML
    private Label lblTitle;
    @javafx.fxml.FXML
    private TableView tblSlots;
    @javafx.fxml.FXML
    private TextField txtSlotSearch;
    @javafx.fxml.FXML
    private Button btnConfirm;
    @javafx.fxml.FXML
    private TableColumn colStatus;

    @javafx.fxml.FXML
    public void initialize() {
    }}